from django.apps import AppConfig


class ModelviewsetAppConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'ModelViewSet_app'
